package com.uuhnaut69.api.model.payload;

import lombok.Data;

@Data
public class UserRequest {
	private String firstName;
	private String lastName;
}
