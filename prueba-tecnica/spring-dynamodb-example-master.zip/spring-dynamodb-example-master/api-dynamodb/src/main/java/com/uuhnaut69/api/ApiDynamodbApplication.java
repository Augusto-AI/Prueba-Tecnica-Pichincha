package com.uuhnaut69.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiDynamodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiDynamodbApplication.class, args);
	}

}
